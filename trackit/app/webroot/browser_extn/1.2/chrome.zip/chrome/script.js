var elemDiv = document.createElement('span');
elemDiv.id="is-cgdgohngjjknfpckhoclbcimpmebjcdf-extn-installed";
document.body.appendChild(elemDiv);