from grouper import *
urls = []
urls.append(["http://www.dsw.com/shoe/aston+grey+drake+oxford?prodId=250482&category=dsw12cat1970002&activeCats=cat20192,dsw12cat1970002", 1])
urls.append(["http://www.gap.com/browse/product.do?cid=92001&vid=1&pid=351511202", 1])
urls.append(["http://www.express.com/clothing/ankle+rolled+destroyed+boyfriend+jean/pro/6995673/cat2005", 1])
urls.append(["http://www.anthropologie.com/anthro/product/clothes-new/29245875.jsp?cm_sp=Grid-_-29245875-_-Regular_0", 1])
urls.append(["http://www.jcrew.com/womens_category/CashmereShop/PRDOVR~53268/53268.jsp", 1])
urls.append(["http://shop.nordstrom.com/s/rbl-military-jumpsuit/3562432?origin=category&contextualcategoryid=0&fashionColor=&resultback=0", 1])
urls.append(["http://www.ae.com/web/browse/product.jsp?productId=1144_9704_443&catId=cat6470451", 1])
urls.append(["http://www.anntaylor.com/one-button-tweed-jacket/321485?colorExplode=false&skuId=14764806&catid=cata000013&productPageType=fullPriceProducts&defaultColor=7030", 1])
urls.append(["http://us.asos.com/D-Struct-Flag-Sneakers/11n9pk/?iid=3312355&cid=1935&sh=0&pge=0&pgesize=36&sort=-1&clr=Blue&mporgp=L0QtU3RydWN0L0QtU3RydWN0LUZsYWctUGxpbXNvbGxzL1Byb2Qv", 1])
urls.append(["http://athleta.gap.com/browse/product.do?cid=1000054&vid=1&pid=918993&mlink=46750,7184035,TSAlacrity9_24&clink=7184035", 1])
urls.append(["http://www1.bloomingdales.com/shop/product/modern-fiction-leather-cap-toe-oxfords?ID=831579&CategoryID=1001314#fn=spp%3D1%26ppp%3D96%26sp%3D1%26rid%3D82%26spc%3D139", 1])
urls.append(["http://www.forever21.com/Product/Product.aspx?BR=f21&Category=bottom_pants&ProductID=2000065458&VariantID=", 1])
urls.append(["http://www.loft.com/julie-skinny-corduroy-pants/314298?colorExplode=false&skuId=14505287&catid=catl000015&productPageType=fullPriceProducts&defaultColor=7512", 1])
urls.append(["http://www.hollisterco.com/shop/us/dudes-skinny-jeans/hollister-skinny-jeans-1150452_01", 1])
urls.append(["http://www.lanebryant.com/active/active-view-all/striped-active-hoodie/20230c20233p193524/index.pro?selectedColor=Heather%20charcoal&selectedSize=26%2F28", 1])
urls.append(["http://www.gillyhicks.com/shop/us/clothing-long-sleeve-graphic-tees/cheeky-definition-graphic-hoodie-1315172_01", 1])
urls.append(["http://www1.macys.com/shop/product/ralph-lauren-polo-red-gift-set?ID=1050356&CategoryID=30088#fn=sp%3D1%26spc%3D1472%26ruleId%3D57%26slotId%3Drec(2)", 1])


i = len(urls)-1
while i>=0:
	url = urls[i]
	print "##################"
	print url[0]
	if url[1]:
		gr = Grouper(url[0])
		try:
			gr.extract()
		except Exception, e:
			print "Exception"
			print e
		#gr.extract()
		gr.deinit()
		print "###############"
	i = i-1

while True:
	time.sleep(10);

