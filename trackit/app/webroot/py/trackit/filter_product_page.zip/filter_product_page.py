import sys
import urllib
import urllib2
import urlparse
import const
from const import *

import BeautifulSoup
from BeautifulSoup import BeautifulSoup, Comment

import misc
from misc import *
import htmlops
from htmlops import *
from tag_classifier import *

import SeleniumReader
from SeleniumReader import *

import random


class ProductListingPage:
	def __init__(self, url):
		self.listing_url = url
		self.reader = SeleniumReader(url);
		
	# Creates different bins based on (width, height) pair of images
	# Sort all images on the page in different bins
	# Pick the bin that has at least 8 images of height >=90 and width >= 90
	# returns list of those image el
	def doesElementHasProductsListed(self, ele):
		
		threshold = 8
		divs = ele.find_elements_by_tag_name("img")
		ge = {}
		
		product_divs = []
		max = 0
		for div in divs:
			if div.size['width'] < 90:
				continue
			if div.size['height'] < 90:
				continue
				
			w = div.size['width']
			h = div.size['height']
			
			if w not in ge:
				ge[w] = {}
			if h not in ge[w]:
				ge[w][h] = []
				
			ge[w][h].append(div)
			bin_size = len(ge[w][h])
			if  bin_size> max and bin_size >= threshold:
				max = bin_size
				product_divs = ge[w][h]
		
		
		return [max,product_divs]
	
	def thingsBelowReviewDivs(self, review_divs):
		
		driver = self.reader.getDriver()
		divs = driver.find_elements_by_tag_name("div")
		
		belowReviewDiv = []
		y1Min = 10000000
		for r in review_divs:
			y1 = r.location['y'];
			if y1 < y1Min:
				y1Min = y1
		
		
		for r in divs:
			y1 = r.location['y'];
			if y1 > y1Min:
				belowReviewDiv.append(r)
				
		
		for div in belowReviewDiv:
			self.reader.dimElement(div, 0.2)
			
		return belowReviewDiv
		

	def detectReviews(self, product_div):
		driver = self.reader.getDriver()
		divs = driver.find_elements_by_tag_name("div")
		
		# find a div that does not contain product div 
		# and is of size 4 times greater than product div
		product_div_area = product_div.size['width'] * product_div.size['height']
		product_div_x1 = product_div.location['x']
		product_div_x2 = product_div_x1 + product_div.size['width']
		product_div_y1 = product_div.location['y']
		product_div_y2 = product_div_y1 + product_div.size['height']
		
		review_divs = []
		max = 0
		for div in divs:
			
			try:
				if False == div.is_displayed():
					continue
			except Exception, e:
				print "Element not found when checking if it is displayed, assuming element not displayed and skipping\n"
				continue
				
			x1 = div.location['x']
			y1 = div.location['y']
			x2 = x1 + div.size['width']
			y2 = y1 + div.size['height']
			
			if product_div_area * 4 > (x2-x1)*(y2-y1):
				print "area less then threshold\n"
				continue
			
			if product_div_x1 >= x1 and product_div_x2 <= x2 and product_div_y1 >= y1 and product_div_y2 <= y2:
				print "product div not completely outside\n"
				continue
			
			#if h > w:	# we are looking for a rectangle with height < width type of shape
			#	continue
			
			# what is this div ? of size greater than 4 times image div
			# and completely outside of it
			# lets do some more checking
			# ensure that this falls below the product image
			if y1 < product_div_y2:
				print "product div not above\n"
				continue
			
			# now I am getting supicious, 
			# but it may contain product details :(
			# look for children, should have at least 4 children
			# that are x1 and x2 aligned
			
			# Ok, this is TODO 
			print "appending " + str(div) + "\n"
			review_divs.append(div)
			
		for div in review_divs:
			self.reader.dimElement(div, 0.2)

		return review_divs
		
		
	def getProductImgDiv(self):
		
		driver = self.reader.getDriver()
		divs = driver.find_elements_by_tag_name("img")
		ge = {}
		
		product_div = []
		max = 0
		for div in divs:
			if False == div.is_displayed():
				continue
			w = div.size['width']
			h = div.size['height']
			
			if w < 90 or h < 90:
				continue
				
			if h < w:	# we are looking for a rectangle with height > width type of shape
				continue
			
			if w not in ge:
				ge[w] = {}
			if h not in ge[w]:
				ge[w][h] = []
				
			area = w*h
			ge[w][h].append([div, area])
			bin_size = len(ge[w][h])
			
			if  area> max:
				max = area
				product_div = div

				
		return product_div
				
	
	def getProductsListed():
		
		re = self.doesElementHasProductsListed(self, self.reader.getDriver())
		
		if re[0] == 0:
			return []
		else:
			pEle = re[1][0]
			parent_re = self.reader.getParentOfWebElement(pEle)
			while parent_re[0] == 1:
				pEle = parent_re[1]
				re = self.doesElementHasProductsListed(self, pEle)
				if re[0] > 0:
					product_list = re[1]
					return product_list;
					
				parent_re = self.reader.getParentOfWebElement(self, pEle)
				
				
	
	def hideDistractingImages():
		
		driver = self.reader()
		divs = driver.find_elements_by_tag_name("img")
		for div in divs:
			div.get
		
	
	def removeOutgoingElements():
		
		driver = reader.getDriver()
		curl = driver.current_url
		for div in divs:
			div_url = driver.execute_script(js, div)
			if curl == div_url:
					continue
			
			if True == div_url.startswith(curl+"#"):
					continue
			
			if "javascript" in div_url:
					continue
			
			reader.removeElement(div)

	
	def binSimilarTextCSSElements():
		
		
		driver = reader.getDriver()
		
		
			
			
	def pluckRelatedImages():
		
		re = self.doesElementHasProductsListed(self, self.reader.getDriver())
		
		if re[0] == 0:
			return []
		else:
			pEle = re[1][0]
			parent_re = self.reader.getParentOfWebElement(pEle)
			while parent_re[0] == 1:
				pEle = parent_re[1]
				re = self.doesElementHasProductsListed(self, pEle)
				if re[0] > 0:
					product_list = re[1]
					return product_list;
					
				parent_re = self.reader.getParentOfWebElement(self, pEle)
		
		
	
	
	
#p = ProductListingPage("http://shop.nordstrom.com/s/burberry-london-woven-silk-tie/3189709?origin=fashionresultspreview")
p = ProductListingPage(sys.argv[1])
product_div = p.getProductImgDiv()
review_divs = p.detectReviews(product_div)
belowReviewDivs = p.thingsBelowReviewDivs(review_divs)